const home ='Home';
const quoting = 'Quoting';
const customerCheck = 'Eligibility check';
const scopeOfAppointment = 'Scope of Appointment';
const providerSearch = 'Provider Search';
const application='Application'
const logout='Log Out';
const quoteHeading='Quoting';
const customerHeading='Customer Application';
const scopeHeading='Scope of Appointment';
const checkHeading='Eligibility Check Medicare and Medicate';
const quoteContent ='quotations must be identical to the original, using a narrow segment of the source.They must match the source .'
const customerContent ='quotations must be identical to the original, using a narrow segment of the source.They must match the source .'
const eligibilityContent = 'quotations must be identical to the original, using a narrow segment of the source.They must match the source .'
const scopeContent ='quotations must be identical to the original, using a narrow segment of the source.They must match the source .'
const checkContent = 'quotations must be identical to the original, using a narrow segment of the source.They must match the source .'
const heading ='What New! '
const headingContent='Available New Shorter Health Risk Assessment(HRA)forms can be completed upon the enrollment submission.(Link in the submission confirmation).'
const headerContent='Care Gude link to be available in enrollment submission confirmation page fo MA/MAPD (expect ISNP/CSNP)applications.Starting 10/09 schedule yo'
const help='Helpful Tools'
const producer='Producer Tool Box'
const sales='Custom Point/Sales Tool Kit'
const center='Medicare Certificate Training Centre'

//application

const applicationHeading='Application'
const information='Application Requriring More Information'
const prospect='Prospect'

//applicationheader

const manage='Manage Applications'
const view ='View non-electronic application'

const name='MAHE,VAISHNAVI'
const process ='In progress'

const access ='Anthem MediBlue Access'
const core='Core (Regional PPO)'

const date='09/15/2021'
const request='Requested Effective Date'

const num='B5X16685'
const no='ACN No'

const action='Action Needed'

//downarrow
const status='Application Status Details'
const dob='21-09-1973'
const dateofbirth='Date of Birth'
const zipcode='Zipcode'
const zip='560000'
const country='xxxxxxxxx'
const value='Country'
const cell='9087654321'
const phone='Phone'
const upadte='09/15/2021'
const dateupdate='Date Update'
const pdf='PDF'
const none='N/A'
const welcome='Welcome Kit Mailed'
const card='ID Card Mailed'
const recall='Recall(Delegate)'
const transfer='Transfer(Customer)'
const hra='HRA'
const response='Respond RFI'
const need='-Need copy of Medicare Card'
const outreach='-Outreach of missing information'
const late='Status Reson(s)'
const create='create new quote'

//application requiring
const namecontent='Rahul Shyam'
const account='Account'
const accountnum='OD425806'
const last='Last Updated'
const limit='09/01/2020'
const respond='Respond'


//applicationrequiringdown
const leave='-Need Leave Emp Cov Date'
const member='-Need members from 2728'

//prospect
const raj='Raj,Ashi'
const remove='Remove'
const verify='DSNP Verification'

//removepopup
 const popup ='Remove Customer'
 const removecontent='Are you sure you would like to remove the customer?'
 const removename='Sathivika Srinivas'

 const legalprivacy='Legal | Privacy | Version No. 1.0.0'

const app='New Prospect'


export const content = {home , quoting, customerCheck,scopeOfAppointment,providerSearch,application,logout, quoteHeading,customerHeading,scopeHeading,
 checkHeading,quoteContent,customerContent,eligibilityContent,scopeContent,checkContent,heading,headingContent,headerContent,help,producer,sales,center
,applicationHeading,information,prospect,manage,view,name,process,access,core
,date,request,num,no,action,status,dob,dateofbirth,zipcode,zip,country
,value,cell,phone,upadte,dateupdate,pdf,none,welcome,card,recall,transfer
,hra,response,need,outreach,late,create,namecontent,accountnum,account
,last,limit,respond,leave,member,raj,remove,verify,popup,removecontent,removename,legalprivacy,app}